## Setup

### Database
Cria um banco de dados no mysql "ifamprotocolo";
Conexão Mysql: usuario: root, senha: "", host: localhost

Criar uma tabela usuario com campos: id, nome, email, matricula, senha

### Execução
Na pasta source-code execute:

npm install

npm start

### Teste
Instalar o Advanced REST client ou PostMan

Executar uma requisição para http://localhost:3000/api/v1/usuario

Acessar:

http://localhost:3000

